from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime
from sqlalchemy.orm import selectinload
from app.database import SessionLocal, Insight, Label
from app import schema_classifier  # ✅ This is where classify_text() lives

router = APIRouter()

# Pydantic schemas
class InsightCreate(BaseModel):
    insight: str
    labels: Optional[List[str]] = []

class LabelOut(BaseModel):
    name: str

    class Config:
        from_attributes = True

class InsightOut(BaseModel):
    id: int
    insight: str
    labels: List[str]

    class Config:
        from_attributes = True

# POST /insights
@router.post("/insights", response_model=InsightOut)
def create_insight(data: InsightCreate):
    session = SessionLocal()
    try:
        new_insight = Insight(insight=data.insight)

        label_objs = []
        for name in data.labels or []:
            label = session.query(Label).filter_by(name=name).first()
            if not label:
                label = Label(name=name)
                session.add(label)
                session.flush()
            label_objs.append(label)
        new_insight.labels = label_objs

        session.add(new_insight)
        session.commit()

        refreshed = (
            session.query(Insight)
            .options(selectinload(Insight.labels))
            .get(new_insight.id)
        )

        return {
            "id": refreshed.id,
            "insight": refreshed.insight,
            "labels": [label.name for label in refreshed.labels],
        }
    finally:
        session.close()

# GET /insights
@router.get("/insights", response_model=List[InsightOut])
def get_insights(
    label: Optional[str] = Query(None),
    labels: Optional[List[str]] = Query(None),
    q: Optional[str] = Query(None),
    from_date: Optional[datetime] = Query(None, alias="from"),
    to_date: Optional[datetime] = Query(None, alias="to")
):
    session = SessionLocal()
    try:
        query = session.query(Insight)

        if q:
            query = query.filter(Insight.insight.ilike(f"%{q}%"))
        if label:
            query = query.join(Insight.labels).filter(Label.name == label)
        if labels:
            query = query.join(Insight.labels).filter(Label.name.in_(labels)).distinct()
        if from_date:
            query = query.filter(Insight.timestamp >= from_date)
        if to_date:
            query = query.filter(Insight.timestamp <= to_date)

        insights = query.all()

        return [
            {
                "id": i.id,
                "insight": i.insight,
                "labels": [l.name for l in i.labels],
            }
            for i in insights
        ]
    finally:
        session.close()

# POST /classify — classify insight text into life traps
class ClassifyInput(BaseModel):
    text: str

@router.post("/classify")
def classify_insight(data: ClassifyInput):
    try:
        labels = schema_classifier.classify_text(data.text)
        return {"life_traps": labels}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
