from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware
from pathlib import Path
from pydantic import BaseModel

from app.routers import insights  # 👈 corrected import path

app = FastAPI()
app.include_router(insights.router)

# Enable CORS (optional for dev)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Set up frontend serving
frontend_path = Path(__file__).resolve().parent.parent / "frontend" / "build"
index_file = frontend_path / "index.html"

# Serve static files (JS, CSS, images)
app.mount("/static", StaticFiles(directory=frontend_path / "static"), name="static")

# Serve React SPA for root and any unknown route
@app.get("/")
@app.get("/{full_path:path}")
async def serve_frontend(full_path: str = ""):
    if index_file.exists():
        return FileResponse(index_file)
    return {"detail": "index.html not found"}
