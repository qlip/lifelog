import json
import re
from transformers import AutoProcessor, AutoTokenizer, AutoModelForImageTextToText
import torch
from datetime import datetime

GEMMA_PATH = "/Users/dima/.cache/kagglehub/models/google/gemma-3n/transformers/gemma-3n-e2b/1"

tokenizer = AutoTokenizer.from_pretrained(GEMMA_PATH)
processor = AutoProcessor.from_pretrained(GEMMA_PATH)
model = AutoModelForImageTextToText.from_pretrained(
    GEMMA_PATH,
    torch_dtype="auto",
    device_map="auto"
)

LIFE_TRAPS = [
    "Abandonment", "Mistrust and Abuse", "Emotional Deprivation", "Social Exclusion",
    "Defectiveness", "Failure", "Subjugation", "Unrelenting Standards",
    "Entitlement", "Insufficient Self-Control", "Vulnerability to Harm or Illness"
]

LIFE_TRAP_DEFINITIONS = {
    "Abandonment": "The belief that people close to you will leave or abandon you.",
    "Mistrust and Abuse": "The expectation that others will hurt, abuse, or manipulate you.",
    "Emotional Deprivation": "The belief that your emotional needs will never be met by others.",
    "Social Exclusion": "Feeling fundamentally different from others and that you don't belong.",
    "Defectiveness": "A deep sense that you are flawed or unlovable.",
    "Failure": "Belief that you will inevitably fail or are fundamentally inadequate.",
    "Subjugation": "The feeling that your needs and opinions are less important, and must be suppressed.",
    "Unrelenting Standards": "A belief that you must meet extremely high standards, often to avoid criticism.",
    "Entitlement": "The belief that you're special and should not have to follow rules or norms.",
    "Insufficient Self-Control": "Struggling with self-discipline and frustration tolerance.",
    "Vulnerability to Harm or Illness": "Excessive fear that catastrophe is imminent (illness, accidents, financial collapse)."
}


def classify_with_gemma(journal_entry: str) -> str:
    # Definitions as numbered list
    numbered_definitions = "\n".join(
        [f"{i+1}. {name}: {desc}" for i, (name, desc) in enumerate(LIFE_TRAP_DEFINITIONS.items())]
    )

    prompt = (
        "You are a psychology assistant trained in schema therapy.\n"
        "Your task is to classify a journal entry into 1–3 relevant psychological life traps.\n"
        "Here are the available life traps:\n\n"
        f"{numbered_definitions}\n\n"
        "Please respond ONLY with a valid JSON array of trap names.\n"
        "Use EXACT trap names from the list above.\n"
        "DO NOT include explanations, prefixes, or additional text.\n\n"
        f"Journal Entry:\n\"{journal_entry}\"\n\n"
        "Response:\n"
    )

    inputs = processor(text=prompt, return_tensors="pt").to(model.device, dtype=model.dtype)
    outputs = model.generate(
        **inputs,
        max_new_tokens=128,
        do_sample=False,        # Deterministic output
        temperature=0.0,        # Max stability
        num_beams=3,
        early_stopping=True
    )

    decoded = processor.batch_decode(outputs, skip_special_tokens=True)[0]
    print("RAW Gemma response:", decoded)
    return decoded


def classify_text(text: str) -> list:
    raw_response = classify_with_gemma(text)
    print("Processed response from Gemma:", raw_response)

    # Match JSON array
    match = re.search(r"\[[^\]]*\]", raw_response, re.DOTALL)
    if match:
        try:
            parsed = json.loads(match.group(0))
            filtered = [trap for trap in parsed if trap in LIFE_TRAPS]
            if filtered:
                return filtered
            else:
                log_mismatch(text, raw_response, "No valid trap names matched.")
                return []
        except Exception as e:
            log_mismatch(text, raw_response, f"JSON decode error: {e}")
            return []
    else:
        fallback = re.findall(r"\b(?:%s)\b" % "|".join(map(re.escape, LIFE_TRAPS)), raw_response)
        if fallback:
            print("Used fallback trap extraction:", fallback)
            return list(set(fallback))
        else:
            log_mismatch(text, raw_response, "No valid array found in model output.")
            return []


def log_mismatch(input_text: str, raw_output: str, reason: str):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open("mismatches.log", "a") as f:
        f.write(f"\n---\n[{timestamp}]\nInput: {input_text}\nReason: {reason}\nOutput: {raw_output}\n")
