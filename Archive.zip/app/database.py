from sqlalchemy import create_engine, Column, Integer, String, Text, DateTime, ForeignKey, Table
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import relationship, sessionmaker
from datetime import datetime

Base = declarative_base()

# Many-to-many relationship table
insight_labels = Table(
    'insight_labels',
    Base.metadata,
    Column('insight_id', Integer, ForeignKey('insights.id'), primary_key=True),
    Column('label_id', Integer, ForeignKey('labels.id'), primary_key=True)
)

class Insight(Base):
    __tablename__ = 'insights'

    id = Column(Integer, primary_key=True)
    insight = Column(Text, nullable=False)
    timestamp = Column(DateTime, default=datetime.utcnow)
    labels = relationship('Label', secondary=insight_labels, back_populates='insights')

class Label(Base):
    __tablename__ = 'labels'

    id = Column(Integer, primary_key=True)
    name = Column(String, unique=True, nullable=False)
    insights = relationship('Insight', secondary=insight_labels, back_populates='labels')

# Set up SQLite database
engine = create_engine('sqlite:///lifelog.db')
Base.metadata.create_all(engine)

# Session setup
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# --- CRUD FUNCTIONS ---

def create_label_if_not_exists(session, name: str):
    label = session.query(Label).filter(Label.name == name).first()
    if not label:
        label = Label(name=name)
        session.add(label)
        session.commit()
        session.refresh(label)
    return label

def add_insight(text: str, label_names: list[str]):
    session = SessionLocal()
    try:
        new_insight = Insight(insight=text)
        for name in label_names:
            label = create_label_if_not_exists(session, name)
            new_insight.labels.append(label)
        session.add(new_insight)
        session.commit()
        print(f"Insight added: {text}")
    finally:
        session.close()

def get_insights_by_label(label_name: str):
    session = SessionLocal()
    try:
        label = session.query(Label).filter(Label.name == label_name).first()
        if label:
            return [(insight.id, insight.insight, [l.name for l in insight.labels]) for insight in label.insights]
        return []
    finally:
        session.close()

def list_all_labels():
    session = SessionLocal()
    try:
        return [label.name for label in session.query(Label).all()]
    finally:
        session.close()
