from dataclasses import dataclass
from typing import List

@dataclass
class Entry:
    id: int
    insight: str
    labels: List[str]