from app.database import (
    add_insight,
    get_insights_by_label,
    list_all_labels,
    Base,
    engine
)

# This ensures the DB file and tables are created (you can call it once at the top)
Base.metadata.create_all(engine)

# Add a new insight with labels
add_insight("I always feel like I’ll be abandoned by people I trust.", ["Abandonment", "Mistrust and Abuse"])

# Fetch insights by label
results = get_insights_by_label("Abandonment")
print("📌 Insights for 'Abandonment':")
for res in results:
    print(res)

# List all labels
print("🏷️ All labels:", list_all_labels())
