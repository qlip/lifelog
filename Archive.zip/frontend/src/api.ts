export async function createInsight(insight: string, labels: string[] = []) {
  const response = await fetch('/insights', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ insight, labels }),
  });
  return response.json();
}

export async function classifyText(text: string) {
  const response = await fetch('/classify', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ text }),
  });
  return response.json();
}

export async function getInsights() {
  const response = await fetch('/insights');
  return response.json();
}
