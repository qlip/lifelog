/// <reference path="./custom.d.ts" />
import React, { useEffect, useState } from 'react';
import './App.css';

type Insight = {
  id: number;
  insight: string;
  labels: string[];
};

export default function App() {
  const [insights, setInsights] = useState<Insight[]>([]);
  const [inputText, setInputText] = useState('');
  const [loading, setLoading] = useState(false);
  const [recording, setRecording] = useState(false);
  const [recognition, setRecognition] = useState<any>(null);

  // Load insights on page load
  useEffect(() => {
    fetch('/insights')
      .then(res => res.json())
      .then((data) => {
        setInsights(data.reverse()); // reverse to show newest first
      })
      .catch(err => console.error('Failed to load insights:', err));
  }, []);

  // Set up speech recognition
  useEffect(() => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      alert('Speech recognition not supported in this browser.');
      return;
    }

    const recog = new SpeechRecognition();
    recog.lang = 'en-US';
    recog.interimResults = false;
    recog.maxAlternatives = 1;

    recog.onresult = (event: SpeechRecognitionEvent) => {
      const transcript = event.results[0][0].transcript;
      setInputText(transcript);
    };

    recog.onerror = (event: any) => {
      console.error('Speech recognition error:', event.error);
      setRecording(false);
    };

    recog.onend = () => {
      setRecording(false);
    };

    setRecognition(recog);
  }, []);

  const toggleRecording = () => {
    if (!recognition) return;

    if (recording) {
      recognition.stop();
      setRecording(false);
    } else {
      setInputText('');
      recognition.start();
      setRecording(true);
    }
  };

  const handleSubmit = async () => {
    if (!inputText.trim()) return;

    setLoading(true);

    try {
      // Classify life traps
      const classifyRes = await fetch('/classify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: inputText }),
      });
      const { life_traps } = await classifyRes.json();

      // Save the insight with labels
      const saveRes = await fetch('/insights', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ insight: inputText, labels: life_traps }),
      });

      const newInsight = await saveRes.json();
      setInsights(prev => [newInsight, ...prev]); // newest on top
      setInputText('');
    } catch (error) {
      console.error('Error submitting insight:', error);
    }

    setLoading(false);
  };

  return (
    <div className="App">
      <h1>Lifelog Insights</h1>

      <textarea
        value={inputText}
        onChange={e => setInputText(e.target.value)}
        placeholder="Write your insight here..."
        rows={4}
        cols={50}
        disabled={loading}
      />

      <br />
      <button onClick={toggleRecording} disabled={loading}>
        {recording ? 'Stop Recording' : '🎙️ Record Insight'}
      </button>

      <br />
      <button onClick={handleSubmit} disabled={loading}>
        {loading ? 'Processing...' : 'Submit Insight'}
      </button>

      <h2>Saved Insights</h2>
      <ul>
        {insights.map(({ id, insight, labels }) => (
          <li key={id}>
            <strong>{insight}</strong>
            <br />
            <em>Labels: {labels.join(', ') || 'None'}</em>
          </li>
        ))}
      </ul>
    </div>
  );
}
